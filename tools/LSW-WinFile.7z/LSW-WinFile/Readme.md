# LSW-WinFile
Recently Microsoft released its old Windows 3.1 File-Manager [WinFile](https://github.com/microsoft/winfile), which this tool is build on.

It is a Test-bed for my AI-Tools which helps to "renovate" Software.

It contains [Scintilla](https://scintilla.org).
Clicking on a file displays its content in a Scintilla MDI-Child Window - the **Terminal-Window**. Clicking on files in the right pane of a **Folder-Window** shows
the File-Content in the **Terminal-Window**.

- Terminal-Window ( **TW**)

  if you run Windows 1903, the **TW** acts as an Output-Console for Consol-Programs started via Context-Menu **Run..** 

- [Javascript](https://github.com/microsoft/ChakraCore)

  Javascript can be directly evaluated.
  You need to Add the JavaScript Plugin in **WinFile.ini**.
  Select a Javascript file & click on Menu Javascript->Execute.
  The result is displayed in the Terminal Window.

- [C](https://bellard.org/tcc/)

C can be directly evaluated. Save the text below in a C-File, select it in a Folder-Window and click on Menu **C -> Execute**.
The result is shown in the Terminal-Window (result = 3628800)

```
int fac(n) {
	if (n == 0)
		return 1;
	else
		return fac(n-1) * n;
}

int main(int argc, char **argv) {
	return fac(10);
}
```
The C-File is compiled dynamically before the main is executed. The underlying TCC is very fast - Windows GUI is also supported & an example will be added soon.

### WinFile.ini

**WinFile.ini** is located at <C:\Users\<YourName>\AppData\Roaming\LSW\WinFile>


## Bugs
- I experience crashes when moving the mouse in the  **TW** due to illegal calls of destructors caused by <unique_ptr>.
- If you close the **TW** there is no way to open the **TW** other than to restart **WinFile-LSW**
- Saved Windows are duplicated so you have to edit WinFile.ini manually to delete the Windows. 

I plan to add:
- [Rust](rust-lang.org)

  Rust-Files can be directly evaluated

- Smalltalk

  Smalltalk can be directly evaluated

- Python

  Python can be directly evaluated