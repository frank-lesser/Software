# LSW-WinFile
Recently Microsoft released its old Windows 3.1 File-Manager [WinFile](https://github.com/microsoft/winfile), which this tool is build on.

It is a Test-bed for my AI-Tools which helps to "renovate" Software.

It contains [Scintilla](https://scintilla.org).
Clicking on a file displays its content in a Scintilla MDI-Child Window.

I plan to add:
- [Rust](rust-lang.org)

  Rust-Plugins can be directly evaluated
- [Javascript](https://github.com/microsoft/ChakraCore)

  Javascript can be directly evaluated

- Smalltalk

  Smalltalk can be directly evaluated