# LSW-ScintillaPad
Standalone Win10 x64 build of [Scintilla](https://www.scintilla.org)
using [JSONBox](http://anhero.github.io/JsonBox/index.htm)
# Features
- fast - can read huge files 
- lexing all SciLexer supported languages
- lexer index can be set in JSON
# Keyword settings implemented for
- html, javascript & vbscript
