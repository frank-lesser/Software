## Files
- pdbex.exe
PDB extraction utility based on
<https://github.com/wbenny/pdbex> ,
enhanced to output JSON and demangle names.

- [msdia.dll](https://docs.microsoft.com/en-us/visualstudio/productinfo/2017-redistribution-vs#VisualStudio)

- [pdbex-license](pdbex-license.txt)

- [llvm-license](llvm-license.txt)